/**
 * 
 */
package fr.utt.lo02.joueur;

/**
 * @see Joueur
 */
public class IA extends Joueur {

	public IA(String nomJoueur, int numJoueur) {
		super(nomJoueur, numJoueur);
	}
	
	
}
